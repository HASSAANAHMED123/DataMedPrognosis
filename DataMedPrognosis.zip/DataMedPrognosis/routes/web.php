<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\Auth\PasswordChangeController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\Customer;
use App\Http\Controllers\DiseasePredictor;
use App\Http\Controllers\DiseasePredictorController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Auth::routes();

Route::get('/', [PageController::class, 'welcome'])->name('welcome');
Route::get('/blogs', [PageController::class, 'blogs'])->name('blogs');
Route::get('/blogs/{blog}', [PageController::class, 'blogShow'])->name('blogs-show');
Route::get('/contact-us', [PageController::class, 'contact'])->name('contact-us');
Route::get('/disease-predictor', [DiseasePredictorController::class, 'index'])
    ->name('disease-predictor');
Route::get('/disease-predictor/predict', [DiseasePredictorController::class, 'predict'])
    ->name('disease-predictor.predict');


/*----------------User role=admin Routes---------------------*/
Route::middleware('auth')->group(function () {
    Route::middleware('can:isAdmin')->prefix('admin')->group(function () {
        Route::get('dashboard', [Admin\DashboardController::class, 'index'])
            ->name('admin-dashboard');

        Route::resource('doctors', Admin\DoctorController::class)
            ->except('show');
        Route::resource('products', Admin\ProductController::class)
            ->except('show');
        Route::resource('customers', Admin\CustomerController::class)
            ->only(['index']);
        Route::resource('orders', Admin\OrderController::class)
            ->only('index', 'show');
        Route::resource('blogs', Admin\BlogController::class)->except('show');

        Route::get('appointments', [Admin\AppointmentController::class, 'index'])
            ->name('appointments.index');
        Route::put('appointments/{appointment}/accept', [Admin\AppointmentController::class, 'accepted'])
            ->name('appointments.accept');
        Route::put('appointments/{appointment}/reject', [Admin\AppointmentController::class, 'rejected'])
            ->name('appointments.reject');

        // Settings
        Route::resource('/settings', Admin\SettingController::class)
            ->only(['index', 'store']);
    });

    /*----------------User role=customer Routes---------------------*/

    Route::middleware('can:isCustomer')->group(function () {
        Route::get('dashboard', [Customer\DashboardController::class, 'index'])
            ->name('customer-dashboard');

        Route::get('my-appointments', [Customer\MyAppointmentController::class, 'index'])
            ->name('my-appointments');
        Route::get('my-orders', [Customer\MyOrderController::class, 'index'])
            ->name('my-orders');
        Route::resource('profile', Customer\ProfileController::class)
            ->only(['index', 'store']);

        Route::get('book-appointment', [Customer\BookAppointmentController::class, 'index'])
            ->name('book-appointment.index');
        Route::post('book-appointment', [Customer\BookAppointmentController::class, 'book'])
            ->name('book-appointment.book');

        Route::get('book-appointment/available-slots', [Customer\BookAppointmentController::class, 'getAvailableSlots'])
            ->name('book-appointment.available-slots');
    });

    /*----------------All Users routes---------------------*/
    Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
    Route::get('/cart/{cartItem}/remove', [CartController::class, 'remove'])->name('cart.remove');
    Route::get('/cart', [CartController::class, 'index'])->name('cart');
    Route::get('/cart/checkout', [CartController::class, 'checkout'])->name('cart.checkout');
    Route::get('/store', [PageController::class, 'store'])->name('store');
    Route::post('/change-password', [PasswordChangeController::class, 'change'])->name('change-password');
});
