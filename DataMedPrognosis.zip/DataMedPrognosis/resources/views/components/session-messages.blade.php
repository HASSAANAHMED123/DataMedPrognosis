<div class="col-6">
    @if (session()->has('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif

    @if (session()->has('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if (session()->has('warn'))
        <div class="alert alert-warning" role="alert">
            {{ session('warn') }}
        </div>
    @endif
</div>
