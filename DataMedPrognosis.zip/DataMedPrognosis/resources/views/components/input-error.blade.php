@error($field)
    <span class="m-2 text-danger text-error">{{ $message }}</span>
@enderror