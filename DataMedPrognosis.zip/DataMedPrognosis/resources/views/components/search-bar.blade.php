@props(['route'])
<form action="{{ $route }}" method="GET">
    <div class="input-group">
        <input type="text" class="form-control" placeholder="search..." value="{{ request()->query('search') }}"
            name="search">
        <div class="input-group-btn mx-2">
            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
