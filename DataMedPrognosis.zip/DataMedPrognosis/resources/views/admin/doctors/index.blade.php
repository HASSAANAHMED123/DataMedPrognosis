@extends('layouts.admin.app')
@section('title', 'Doctors')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-end p-1">
                <a class="btn btn-primary" href="{{ route('doctors.create') }}">Create</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Doctors</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('doctors.index') }}" />
                    </div>
                </div>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Img</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Total Appointments</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($doctors as $key => $doctor)
                                    <tr>
                                        <td> <span class="badge badge-primary">#{{ $doctor->id }}</span></td>
                                        <td>
                                            <img src="{{ $doctor->getFirstMediaUrl('display-photo') }}" alt="no image"
                                                width="50" height="50">
                                        </td>
                                        <td> {{ $doctor->name }}</td>
                                        <td> {{ $doctor->email }}</td>
                                        <td>
                                            <span
                                                class="badge badge-info">{{ number_format($doctor->appointments_count ?? 0) }}</span>
                                        </td>
                                        <td>{{ $doctor->created_at->format('h:i a d-m-Y') }}</td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="{{ route('doctors.edit', $doctor->id) }}" class="btn btn-primary">
                                                    Edit
                                                </a> |
                                                <form action="{{ route('doctors.destroy', $doctor->id) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-danger">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $doctors->links() }}
                        @unless (filled($doctors))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No doctors found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
@endsection
