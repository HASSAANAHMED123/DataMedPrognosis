@extends('layouts.admin.app')
@section('title', isset($doctor) ? 'Doctor Update' : 'Doctor Create');
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4>{{ isset($doctor) ? 'Update' : 'Create' }} Doctor</h4>
                </div>
                <div class="card-body">
                    <form action="{{ isset($doctor) ? route('doctors.update', $doctor->id) : route('doctors.store') }}"
                        method="post" enctype="multipart/form-data">
                        @isset($doctor)
                            @method('PUT')
                            @endif
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input name="name" type="text"
                                            value="{{ old('name', isset($doctor) ? $doctor->name : '') }}" class="form-control"
                                            required>
                                        <x-input-error field="name" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input name="email" type="email"
                                            value="{{ old('email', isset($doctor) ? $doctor->email : '') }}"
                                            class="form-control" required>
                                        <x-input-error field="email" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Department</label>
                                        <input name="department" type="department" class="form-control"
                                            value="{{ old('department', isset($doctor) ? $doctor->department : '') }}"
                                            @required(!isset($doctor)) />
                                        <x-input-error field="department" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Display Photo</label>
                                        <input name="image" type="file" accept="image/*" class="form-control">
                                        <x-input-error field="image" />
                                    </div>
                                </div>
                                @isset($doctor)
                                    <div class="col-6 mb-2">
                                        <p>If you upload a new image, it will replace with new one</p>
                                        <img width="130" height="130" src="{{ $doctor->getFirstMediaUrl('display-photo') }}"
                                            alt="no-image">
                                    </div>
                                @endisset
                            </div>
                            <button class="btn btn-primary">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Main Content -->
    @endsection
