@extends('layouts.admin.app')
@section('title', 'Blogs')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-end p-1">
                <a class="btn btn-primary" href="{{ route('blogs.create') }}">Create</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Blogs</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('blogs.index') }}" />
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>#</th>
                                <th>Img</th>
                                <th>Title</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                            @foreach ($blogs as $key => $blog)
                                <tr>
                                    <td>{{ ++$key }}</td>
                                    <td>
                                        <img src="{{ $blog->getFirstMediaUrl('cover-photo') }}" alt="no image"
                                            width="50" height="50">
                                    </td>
                                    <td>{{ $blog->title }}</td>
                                    <td>{{ $blog->created_at }}</td>
                                    <td>
                                        <div class="d-flex ">

                                            <a href="{{ route('blogs.edit', $blog->id) }}" class="btn btn-primary">
                                                Edit
                                            </a>|
                                            <form action="{{ route('blogs.destroy', $blog->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-danger">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                        {{ $blogs->links() }}
                        @unless (filled($blogs))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No blogs found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
@endsection
