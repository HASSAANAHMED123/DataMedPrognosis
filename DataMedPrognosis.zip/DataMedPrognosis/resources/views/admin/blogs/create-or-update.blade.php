@extends('layouts.admin.app')
@section('title', 'Blogs Create')
@section('content')
    <!-- Start Main Content -->

    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4>{{ isset($blog) ? 'Update' : 'Create' }} Blog</h4>
                </div>
                <div class="card-body">
                    @if (isset($blog))
                        <form action="{{ route('blogs.update', $blog->id) }}" method="post" enctype="multipart/form-data">
                            @method('PUT')
                        @else
                            <form action="{{ route('blogs.store') }}" method="post" enctype="multipart/form-data">
                    @endif
                    @csrf
                    <div class="form-group">
                        <div class="row">
                            <div class="col-6">
                                <label>Cover Image</label>
                                <input name="image" type="file" accept="image/*" class="form-control">
                                <x-input-error field="image" />
                            </div>
                            <div class="col-6">
                                @isset($blog)
                                    <div>
                                        <label>Current Cover Image</label>
                                        <br>
                                        <img width="100" height="50" src="{{ $blog->getFirstMediaUrl('cover-photo') }}"
                                            alt="no-image">
                                    </div>
                                @endisset
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Title</label>
                        <input name="title" type="text" value="{{ old('title', isset($blog) ? $blog->title : '') }}"
                            class="form-control">
                        <x-input-error field="title" />
                    </div>
                    <div class="form-group">
                        <label>Short Desc.</label>
                        <textarea name="short_desc" rows="5" class="form-control">{{ old('short_desc', isset($blog) ? $blog->short_desc : '') }}</textarea>
                        <x-input-error field="short_desc" />
                    </div>
                    <div class="form-group">
                        <label>Blog</label>
                        <textarea id="summernote" name="blog">{{ old('blog', isset($blog) ? $blog->blog : '') }}</textarea>
                        <x-input-error field="blog" />
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
    @push('scripts')
        <script>
            $.getScript('https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.js', function() {
                $('#summernote').summernote({
                    dialogsInBody: true,
                    minHeight: 150,
                    toolbar: [
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['fontsize', ['fontsize']],
                        ['color', ['forecolor', 'backcolor']],
                        ['para', ['paragraph']],
                        ['height', ['height']],
                        ['insert', ['link', 'hr', 'table']],
                        ['view', ['fullscreen', 'codeview']],
                    ]
                });
            });
        </script>
    @endpush
@endsection
