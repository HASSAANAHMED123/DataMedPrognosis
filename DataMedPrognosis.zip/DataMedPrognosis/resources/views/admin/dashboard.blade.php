@extends('layouts.admin.app')
@section('title', 'Dashboard')
@section('content')
    <!-- Start Main Content -->
    <section class="section">
        <h4>Dashboard</h4>
        <div class="row">
            @foreach ($cards as $key => $value)
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card p-3">
                        <h5>{{ ucfirst($key) }}</h5>
                        <div class="ml-auto">
                            <h5><span class="text-success"> {{ $value }}</span></h5>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </section>
@endsection
