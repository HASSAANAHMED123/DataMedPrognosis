@extends('layouts.admin.app')
@section('title', 'Orders')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Orders</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('orders.index') }}" />
                    </div>
                </div>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Total Amount (Rs)</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($orders as $key => $order)
                                    <tr>
                                        <td> <span class="badge badge-primary">#{{ $order->id }}</span></td>

                                        <td> {{ $order->customer->name }}</td>
                                        <td> {{ $order->total_amount }}</td>

                                        <td>{{ $order->created_at->format('h:i a d-m-Y') }}</td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="{{ route('orders.show', $order->id) }}" class="btn btn-primary">
                                                    Show
                                                </a> 
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $orders->links() }}
                        @unless (filled($orders))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No orders found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
@endsection
