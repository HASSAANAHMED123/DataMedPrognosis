@extends('layouts.admin.app')
@section('title', 'Order Invoice')
@section('content')
    <!-- Start Main Content -->
    <div class="invoice">
        <div class="invoice-print">
            <div class="row">
                <div class="col-lg-12">
                    <div class="invoice-title">
                        <h2>Order Details</h2>
                        <div class="invoice-number">Order #{{ $order->id }}</div>

                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="section-title">Order Summary</div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-md">
                        <tr>
                            <th data-width="40">#</th>
                            <th>Item</th>
                            <th class="text-center">Price</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-right">Totals</th>
                        </tr>
                        @foreach ($order->details as $key => $item)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td>{{ $item->product->name }}</td>
                                <td class="text-center"> ₹{{ $item->product->price }}</td>
                                <td class="text-center">{{ $item->quantity }}</td>
                                <td class="text-right"> ₹{{ $item->quantity * $item->product->price }}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-8">
                    </div>
                    <div class="col-lg-4 text-right">
                        <div class="invoice-detail-item">
                            <div class="invoice-detail-name">Total</div>
                            <div class="invoice-detail-value invoice-detail-value-lg">₹
                                {{ $order->total_amount }}
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <strong>Order created at: </strong>
                        {{ $order->created_at->format('h:i a d M Y') }}<br><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
@endsection
