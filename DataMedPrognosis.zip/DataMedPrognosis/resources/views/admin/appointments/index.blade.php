@extends('layouts.admin.app')
@section('title', 'Appointments')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Appointments</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('appointments.index') }}" />
                    </div>
                </div>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Doctor Name</th>
                                    <th>Appointment Date </th>
                                    <th>Appointment Time </th>
                                    <th>Status </th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($appointments as $key => $appointment)
                                    <tr>
                                        <td> <span class="badge badge-primary">#{{ $appointment->id }}</span></td>
                                        <td>{{ $appointment->customer->name }}</td>
                                        <td>{{ $appointment->doctor->name }}</td>
                                        <td>{{ $appointment->date }} </td>
                                        <td> {{ $appointment->start_time . '-' . $appointment->finish_time }}
                                        </td>
                                        <td>{{ $appointment->status }} </td>
                                        <td>{{ $appointment->created_at->format('h:i a d-m-Y') }}</td>
                                        <td>
                                            @if ($appointment->status == 'pending')
                                                <div class="d-flex">
                                                    <form method="POST"
                                                        action="{{ route('appointments.accept', $appointment->id) }}">
                                                        @csrf
                                                        @method('PUT')
                                                        <button type="submit" class="btn btn-primary">Accept</button>
                                                    </form>
                                                    |
                                                    <form method="POST"
                                                        action="{{ route('appointments.reject', $appointment->id) }}">
                                                        @csrf
                                                        @method('PUT')
                                                        <button type="submit" class="btn btn-danger">Reject</button>
                                                    </form>
                                                </div>
                                            @else
                                                <h6> No Action</h6>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $appointments->links() }}
                        @unless (filled($appointments))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No appointments found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
@endsection
