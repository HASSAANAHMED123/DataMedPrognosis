<div class="card-header">
    <h4>Change Password</h4>
</div>
<div class="card-body">
    <form action="{{ route('change-password') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label>Password</label>
                    <input name="password" type="password" class="form-control">
                    <x-input-error field="password" />
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input name="password_confirmation" type="password" class="form-control">
                    <x-input-error field="password_confirmation" />
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Change</button>
    </form>
</div>
