<div class="card-header">
    <h4>Settings</h4>
</div>
<div class="card-body">
    <form action="{{ route('settings.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label>Hospital Opening Time</label>
                    <input name="hospital_opening_time" type="time"
                        value="{{ old('hospital_opening_time', $settings->where('key', 'hospital_opening_time')->first()->value ?? '') }}"
                        class="form-control">
                    <x-input-error field="hospital_opening_time" />
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label>Hospital Closing Time</label>
                    <input name="hospital_closing_time" type="time"
                        value="{{ old('hospital_closing_time', $settings->where('key', 'hospital_closing_time')->first()->value ?? '') }}"
                        class="form-control">
                    <x-input-error field="hospital_closing_time" />
                </div>
            </div>
            {{-- <div class="col-6">
                <div class="form-group">
                    <label>Appointment Duration (mins)</label>
                    @php
                        $durations = [15, 30, 60, 120];
                    @endphp
                    <select class="form-control" name="appointment_duration">
                        @foreach ($durations as $duration)
                            <option value="{{ $duration }}" @selected($duration == $settings->where('key', 'appointment_duration')->first()->value ?? '')>
                                {{ $duration }}
                            </option>
                        @endforeach
                    </select>
                    <x-input-error field="appointment_duration" />
                </div>
            </div> --}}
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
