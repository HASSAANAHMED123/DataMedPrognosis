@extends('layouts.admin.app')
@section('title', 'Settings')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                @include('admin.settings.partials.settings')
            </div>
            <div class="card">
                @include('admin.settings.partials.change-password')
            </div>
        </div>
    </div>
@endsection
