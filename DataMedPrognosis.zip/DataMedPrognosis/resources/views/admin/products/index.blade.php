@extends('layouts.admin.app')
@section('title', 'Products')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-end p-1">
                <a class="btn btn-primary" href="{{ route('products.create') }}">Create</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Products</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('products.index') }}" />
                    </div>
                </div>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($products as $key => $product)
                                    <tr>
                                        <td> <span class="badge badge-primary">#{{ $product->id }}</span></td>
                                        <td>
                                            <img src="{{ $product->getFirstMediaUrl('thumbnail') }}" alt="no image"
                                                width="50" height="50">
                                        </td>
                                        <td> {{ $product->name }}</td>
                                        <td> {{ $product->price }}</td>

                                        <td>{{ $product->created_at->format('h:i a d-m-Y') }}</td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="{{ route('products.edit', $product->id) }}"
                                                    class="btn btn-primary">
                                                    Edit
                                                </a> |
                                                <form action="{{ route('products.destroy', $product->id) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-danger">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $products->links() }}
                        @unless (filled($products))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No products found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Content -->
@endsection
