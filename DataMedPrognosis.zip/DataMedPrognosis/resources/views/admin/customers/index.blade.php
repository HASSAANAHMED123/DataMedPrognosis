@extends('layouts.admin.app')
@section('title', 'Customers')
@section('content')
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Customers</h4>
                    <div class="card-header-form">
                        <x-search-bar route="{{ route('customers.index') }}" />
                    </div>
                </div>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Total Appointments</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($customers as $key => $customer)
                                    <tr>
                                        <td> <span class="badge badge-primary">{{ $customer->id }}</span></td>
                                        <td>{{ $customer->name }}</td>
                                        <td>{{ $customer->email }}</td>
                                        <td><span
                                                class="badge badge-info">{{ number_format($customer->appointments_count) }}</span>
                                        </td>
                                        <td>
                                            {{ $customer->created_at->format('h:m a d-m-Y') }}</td>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $customers->links() }}
                        @unless (filled($customers))
                            <div class="mx-4 my-4 d-flex justify-content-center">
                                <h5> No customers found.</h5>
                            </div>
                        @endunless
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
