<div class="col-12 mt-5">
    <hr>
    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0 wow fadeIn" data-wow-delay="0.1s">
        <button type="button" class="navbar-toggler me-4 mb-2" data-bs-toggle="collapse"
            data-bs-target="#customerNavbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="customerNavbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="{{ route('customer-dashboard') }}" @class([
                    'nav-item nav-link',
                    'active' => request()->routeIs('customer-dashboard'),
                ])>Dashboard</a>
                <a href="{{ route('my-appointments') }}" @class([
                    'nav-item nav-link',
                    'active' => request()->routeIs('my-appointments'),
                ])>My Appointments</a>
                <a href="{{ route('my-orders') }}" @class([
                    'nav-item nav-link',
                    'active' => request()->routeIs('my-orders'),
                ])>My Orders</a>
                <a href="{{ route('book-appointment.index') }}" @class([
                    'nav-item nav-link',
                    'active' => request()->routeIs('book-appointment.index'),
                ])>Book Appointment</a>

                <a href="{{ route('profile.index') }}" @class([
                    'nav-item nav-link',
                    'active' => request()->routeIs('profile.index'),
                ])>Profile</a>
                <a class="nav-item nav-link text-danger" href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                    <span> Logout</span>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </div>
        </div>
    </nav>
</div>
