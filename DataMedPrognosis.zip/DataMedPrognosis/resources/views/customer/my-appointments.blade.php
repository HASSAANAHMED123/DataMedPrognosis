@extends('layouts.app.app')
@section('title', 'Appointments')
@section('content')
    <!-- Start Main Content -->
    <div class="container">
        <div class="row">
            @include('customer.partials.navbar')
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Appointments</h4>
                        <div class="col-3">
                            <div class="card-header-form">
                                <x-search-bar route="{{ route('my-appointments') }}" />
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-2">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Doctor Name</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Time </th>
                                        <th>Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($appointments as $key => $appointment)
                                        <tr>
                                            <td> {{ ++$key }} </td>
                                            <td>{{ $appointment->doctor->name }}</td>
                                            <td>{{ $appointment->status }}</td>
                                            <td>{{ $appointment->date }}</td>
                                            <td>{{ $appointment->start_time . '-' . $appointment->finish_time }}</td>
                                            <td>{{ $appointment->created_at->format('h:m a d-m-Y') }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{ $appointments->links() }}
                            @unless (filled($appointments))
                                <div class="mx-4 my-4 d-flex justify-content-center">
                                    <h5> No appointments found.</h5>
                                </div>
                            @endunless
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
