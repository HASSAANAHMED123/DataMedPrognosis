@extends('layouts.app.app')
@section('title', 'Orders')
@section('content')
    <!-- Start Main Content -->
    <div class="container">
        <div class="row">
            @include('customer.partials.navbar')
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Orders</h4>
                        <div class="col-3">
                            <div class="card-header-form">
                                <x-search-bar route="{{ route('my-orders') }}" />
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-2">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Details</th>
                                        <th>Order Total (Rs)</th>
                                        <th>Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($orders as $key => $order)
                                        <tr>
                                            <td> {{ ++$key }} </td>
                                            <td>
                                                @foreach ($order->details as $item)
                                                    {{ '(' . $item->quantity . ')  ' . $item->unit_name . '  (' . $item->unit_price . ' Rs)' }}
                                                    <br>
                                                @endforeach
                                            </td>
                                            <td>{{ $order->total_amount }}</td>
                                            <td>{{ $order->created_at->format('h:m a d-m-Y') }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{ $orders->links() }}
                            @unless (filled($orders))
                                <div class="mx-4 my-4 d-flex justify-content-center">
                                    <h5> No orders found.</h5>
                                </div>
                            @endunless
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
