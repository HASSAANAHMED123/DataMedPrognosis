@extends('layouts.app.app')
@section('title', 'Profile')
@section('content')
    <!-- Start Main Content -->
    <div class="container">
        <div class="row">
            @include('customer.partials.navbar')
            <div class="col-12 col-md-12 col-lg-12">
                <x-session-messages />
                <div class="card  mb-3">
                    <div class="card-header">
                        <h4>Profile</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('profile.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input name="name" type="text" value="{{ auth()->user()->name }}"
                                            class="form-control">
                                        <x-input-error field="name" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input name="email" type="email" value="{{ auth()->user()->email }}"
                                            class="form-control">
                                        <x-input-error field="email" />
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Update</button>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4>Change Password</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('change-password') }}" method="POST">
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input name="password" type="password" class="form-control">
                                        <x-input-error field="password" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input name="password_confirmation" type="password" class="form-control">
                                        <x-input-error field="password_confirmation" />
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Change</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
