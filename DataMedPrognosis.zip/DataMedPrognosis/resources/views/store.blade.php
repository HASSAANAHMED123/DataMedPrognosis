@extends('layouts.app.app')
@section('title', 'Store')
@section('content')
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Store</h1>
        </div>
    </div>
    <!-- Page Header End -->
    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Store</p>
            </div>
            <div class="row">
                <div class="col-12 mb-5">
                    <form action="{{ route('store') }}" method="GET">
                        <div class="d-flex justify-content-center">
                            <div class="col-4">
                                <div class="form-group">
                                    <input type="text" class="form-control mb-2" placeholder="search here...."
                                        name="search" value="{{ request()->query('search') }}">
                                </div>
                            </div>
                            <div>
                                <button class="btn btn-primary mx-2  px-5">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row g-4">
                @forelse ($products as $product)
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item bg-light rounded h-100 p-5">
                            <div class="border-1 mb-4">
                                <img class="img-fluid" width="300px" height="600px"
                                    src="{{ $product->getFirstMediaUrl('thumbnail') }}" alt="{{ $product->name }}">
                            </div>
                            <h4 class="mb-3">{{ ucfirst($product->name) }}</h4>
                            <p class="mb-4">Rs. {{ $product->price }}</p>
                            <a class="btn addToCart" data-id="{{ $product->id }}"><i
                                    class="fa fa-plus text-primary me-3"></i>Add to Cart</a>
                        </div>
                    </div>
                @empty
                    <li>No Products found.</li>
                @endforelse
            </div>
        </div>
    </div>
    <!-- Service End -->
    <div class="modal" id="addToCartModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cart added</h5>
                </div>
                <div class="modal-body">
                    <p>Product has been added.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="closeAddToCartModal">Ok</button>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            $(document).ready(function() {
                // Add to cart
                $(".addToCart").on('click', function() {
                    var productId = $(this).data('id');
                    $.ajax({
                        url: '/cart/add',
                        type: 'POST',
                        data: {
                            product: productId,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(data) {
                            $("#cartCounter").text(data.cartCount);
                            // Show the modal
                            $("#addToCartModal").show();
                        }
                    });
                });
                // Close the modal
                $("#closeAddToCartModal").on('click', function() {
                    $("#addToCartModal").hide();
                })
            });
        </script>
    @endpush
@endsection
