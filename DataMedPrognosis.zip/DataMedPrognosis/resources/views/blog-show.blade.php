@extends('layouts.app.app')
@section('title', 'Blogs')
@section('content')
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Blogs</h1>
        </div>
    </div>
    <!-- Page Header End -->
    <!-- Blogs Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Blogs</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-12 col-md-12 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item bg-light rounded h-100 p-5">
                        <div>
                            <img src="{{ $blog->getFirstMediaUrl('cover-photo') }}" alt="{{ $blog->title }}" class="w-100"
                                width="100%" height="500px">
                        </div>
                        <h4 class="mb-3 mt-5">{{ $blog->title }}</h4>
                        <p class="mx-5" style="text-align: justify;">{{ $blog->short_desc }}</p>
                        <hr>
                        <p class="mb-4" style="text-align: justify;">{!! $blog->blog !!}</p>
                        <hr>
                        <div class="d-flex justify-content-end">
                            <div>
                                <p>Writer: Admin</p>
                                <p>Date: {{ $blog->created_at->format('d-M-Y') }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Blogs End -->
@endsection
