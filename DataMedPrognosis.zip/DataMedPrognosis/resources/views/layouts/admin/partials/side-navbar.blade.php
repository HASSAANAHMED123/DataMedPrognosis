<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="{{ route('admin-dashboard') }}">
                <span class="logo-name">{{ env('APP_NAME') }}</span>
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li @class([
                'dropdown',
                'active' => request()->routeIs('admin-dashboard'),
            ])>
                <a href="{{ route('admin-dashboard') }}" class="nav-link">
                    <i data-feather="monitor"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li @class(['dropdown', 'active' => request()->routeIs('appointments.*')])>
                <a href="{{ route('appointments.index') }}" class="nav-link">
                    <i data-feather="calendar"></i>
                    <span>Appointments</span>
                </a>
            </li>
            <li class="dropdown {{ request()->is('admin/orders**') ? 'active' : '' }}">
                <a href="{{ route('orders.index') }}" class="nav-link">
                    <i data-feather="shopping-bag"></i>
                    <span>Orders</span>
                </a>
            </li>
            <li @class(['dropdown', 'active' => request()->routeIs('products.*')])>
                <a href="{{ route('products.index') }}" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Products</span>
                </a>
            </li>
            <li @class(['dropdown', 'active' => request()->routeIs('customers.*')])>
                <a href="{{ route('customers.index') }}" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Customers</span>
                </a>
            </li>

            <li @class(['dropdown', 'active' => request()->is('admin/blogs*')])>
                <a href="{{ route('blogs.index') }}" class="nav-link">
                    <i data-feather="message-square"></i>
                    <span>Blogs</span>
                </a>
            </li>
            <li @class(['dropdown', 'active' => request()->routeIs('doctors.*')])>
                <a href="{{ route('doctors.index') }}" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Doctors</span>
                </a>
            </li>
            <li @class(['dropdown', 'active' => request()->routeIs('settings.*')])>
                <a href="{{ route('settings.index') }}" class="nav-link">
                    <i data-feather="settings"></i>
                    <span>Settings</span>
                </a>
            </li>
        </ul>
    </aside>
</div>
