@extends('layouts.app.app')
@section('title', 'Blogs')
@section('content')
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Blogs</h1>
        </div>
    </div>
    <!-- Page Header End -->
    <!-- Blogs Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Blogs</p>
            </div>
            <div class="row g-4">
                @forelse($blogs as $blog)
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item bg-light rounded h-100 p-5">
                            <div>
                                <img src="{{ $blog->getFirstMediaUrl('cover-photo') }}" alt="{{ $blog->title }}"
                                    class="w-100 mb-5" width="100%" height="150px">
                            </div>
                            <h4 class="mb-3">{{ $blog->title }}</h4>
                            <p class="mb-4">{{ substr($blog->short_desc, 0, 90).'...' }}</p>
                            <a class="btn" href="{{ route('blogs-show', $blog->slug) }}"><i
                                    class="fa fa-plus text-primary me-3"></i>Read More</a>
                        </div>
                    </div>
                @empty
                    <li>No Blogs found.</li>
                @endforelse
            </div>
        </div>
    </div>
    <!-- Blogs End -->
@endsection
