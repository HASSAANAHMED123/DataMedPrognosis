<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Setting::create(['key' => 'hospital_opening_time', 'value' => '09:00']);
        Setting::create(['key' => 'hospital_closing_time', 'value' => '17:00']);
        Setting::create(['key' => 'appointment_duration', 'value' => '30']);
    }
}
