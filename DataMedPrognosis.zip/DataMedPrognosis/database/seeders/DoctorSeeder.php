<?php

namespace Database\Seeders;

use App\Models\Doctor;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class DoctorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Initialize Faker
        $faker = Faker::create();

        // Doctors data
        $doctorsData = [
            ['name' => 'Abdullah Ch', 'email' => 'abdullah@example.com', 'department' => 'Dentist'],
            ['name' => 'Sara Khan', 'email' => 'sara@example.com', 'department' => 'Surgeon'],
            ['name' => 'Alina Khan', 'email' => 'alina@example.com', 'department' => 'Nephrologist'],
            ['name' => 'Hammad Khan', 'email' => 'hammad@example.com', 'department' => 'Urologist'],
        ];

        foreach ($doctorsData as $doctorData) {
            // Create doctor
            $doctor = Doctor::create($doctorData);

            // Generate a fake image URL
            $imageUrl = $faker->imageUrl();

            // Download the image and add it to media collection
            $doctor->addMediaFromUrl($imageUrl)
                ->toMediaCollection('display-photo');
        }
    }
}
