<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Medical products array
        $medicalProducts = [
            ['name' => 'Payodine', 'price' => 124],
            ['name' => 'Band-Aids', 'price' => 5],
            ['name' => 'Antiseptic Cream', 'price' => 10],
            ['name' => 'First Aid Kit', 'price' => 25],
            ['name' => 'Thermometer', 'price' => 15],
            ['name' => 'Hydrogen Peroxide', 'price' => 8],
            ['name' => 'Cotton Swabs', 'price' => 3],
            ['name' => 'Rubbing Alcohol', 'price' => 7],
            ['name' => 'Gauze Pads', 'price' => 6],
            ['name' => 'Medical Gloves', 'price' => 12]
        ];
        $faker = Faker::create();
        // Create 10 products
        for ($i = 0; $i < 10; $i++) {
            $index = $i % count($medicalProducts);
            $product = Product::create($medicalProducts[$index]);
            $imageUrl = $faker->imageUrl();
            // Download the image and add it to media collection
            $product->addMediaFromUrl($imageUrl)
                ->toMediaCollection('thumbnail');
        }
    }
}
