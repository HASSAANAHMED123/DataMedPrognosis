<?php

namespace Database\Seeders;

use App\Models\Blog;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Str;
class BlogSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $num) {
            $title = fake()->name();
            $blog = Blog::create([
                'title' => $title,
                'slug' => Str::slug($title),
                'short_desc' => fake()->sentence(30),
                'blog' => fake()->sentence(1000),
            ]);
            $imageUrl = $faker->imageUrl();
            $blog->addMediaFromUrl($imageUrl)
                ->toMediaCollection('cover-photo');
        }
    }
}
