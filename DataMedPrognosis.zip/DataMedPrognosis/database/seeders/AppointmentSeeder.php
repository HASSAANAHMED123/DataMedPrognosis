<?php

namespace Database\Seeders;

use App\Models\Appointment;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AppointmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Appointment::create([
            'doctor_id' => 1,
            'customer_id' => 2,
            'status' => 'pending',
            'desc' => 'I have cough from last five days.',
            'date' => now()->format('d-m-Y'),
            'start_time' => '10:00',
            'finish_time' => '10:30',
        ]);

        Appointment::create([
            'doctor_id' => 2,
            'customer_id' => 2,
            'status' => 'pending',
            'desc' => 'I have cough from last five days.',
            'date' => now()->format('d-m-Y'),
            'start_time' => '11:00',
            'finish_time' => '11:30',
        ]);

        Appointment::create([
            'doctor_id' => 3,
            'customer_id' => 2,
            'status' => 'pending',
            'desc' => 'I have cough from last five days.',
            'date' => now()->format('d-m-Y'),
            'start_time' => '12:00',
            'finish_time' => '12:30',
        ]);
    }
}
