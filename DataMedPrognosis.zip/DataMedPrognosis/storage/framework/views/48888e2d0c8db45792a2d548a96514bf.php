    <a href="/" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h1 class="m-0 text-primary"><i class="far fa-hospital me-3"></i><?php echo e(env('APP_NAME')); ?></h1>
    </a>
<?php /**PATH D:\Projects\DataMedPrognosis\resources\views/components/logo.blade.php ENDPATH**/ ?>