<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin-dashboard')); ?>">
                <span class="logo-name"><?php echo e(env('APP_NAME')); ?></span>
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'dropdown',
                'active' => request()->routeIs('admin-dashboard'),
            ]); ?>">
                <a href="<?php echo e(route('admin-dashboard')); ?>" class="nav-link">
                    <i data-feather="monitor"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->routeIs('appointments.*')]); ?>">
                <a href="<?php echo e(route('appointments.index')); ?>" class="nav-link">
                    <i data-feather="calendar"></i>
                    <span>Appointments</span>
                </a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/orders**') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('orders.index')); ?>" class="nav-link">
                    <i data-feather="shopping-bag"></i>
                    <span>Orders</span>
                </a>
            </li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->routeIs('products.*')]); ?>">
                <a href="<?php echo e(route('products.index')); ?>" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Products</span>
                </a>
            </li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->routeIs('customers.*')]); ?>">
                <a href="<?php echo e(route('customers.index')); ?>" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Customers</span>
                </a>
            </li>

            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->is('admin/blogs*')]); ?>">
                <a href="<?php echo e(route('blogs.index')); ?>" class="nav-link">
                    <i data-feather="message-square"></i>
                    <span>Blogs</span>
                </a>
            </li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->routeIs('doctors.*')]); ?>">
                <a href="<?php echo e(route('doctors.index')); ?>" class="nav-link">
                    <i data-feather="users"></i>
                    <span>Doctors</span>
                </a>
            </li>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dropdown', 'active' => request()->routeIs('settings.*')]); ?>">
                <a href="<?php echo e(route('settings.index')); ?>" class="nav-link">
                    <i data-feather="settings"></i>
                    <span>Settings</span>
                </a>
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/layouts/admin/partials/side-navbar.blade.php ENDPATH**/ ?>