<?php $__env->startSection('title', 'Blogs'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Blogs</h1>
        </div>
    </div>
    <!-- Page Header End -->
    <!-- Blogs Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Blogs</p>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item bg-light rounded h-100 p-5">
                            <div>
                                <img src="<?php echo e($blog->getFirstMediaUrl('cover-photo')); ?>" alt="<?php echo e($blog->title); ?>"
                                    class="w-100 mb-5" width="100%" height="150px">
                            </div>
                            <h4 class="mb-3"><?php echo e($blog->title); ?></h4>
                            <p class="mb-4"><?php echo e(substr($blog->short_desc, 0, 90).'...'); ?></p>
                            <a class="btn" href="<?php echo e(route('blogs-show', $blog->slug)); ?>"><i
                                    class="fa fa-plus text-primary me-3"></i>Read More</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>No Blogs found.</li>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Blogs End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/blogs.blade.php ENDPATH**/ ?>