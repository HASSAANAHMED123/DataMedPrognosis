<?php $__env->startSection('title', 'Store'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Store</h1>
        </div>
    </div>
    <!-- Page Header End -->
    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Store</p>
            </div>
            <div class="row">
                <div class="col-12 mb-5">
                    <form action="<?php echo e(route('store')); ?>" method="GET">
                        <div class="d-flex justify-content-center">
                            <div class="col-4">
                                <div class="form-group">
                                    <input type="text" class="form-control mb-2" placeholder="search here...."
                                        name="search" value="<?php echo e(request()->query('search')); ?>">
                                </div>
                            </div>
                            <div>
                                <button class="btn btn-primary mx-2  px-5">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="service-item bg-light rounded h-100 p-5">
                            <div class="border-1 mb-4">
                                <img class="img-fluid" width="300px" height="600px"
                                    src="<?php echo e($product->getFirstMediaUrl('thumbnail')); ?>" alt="<?php echo e($product->name); ?>">
                            </div>
                            <h4 class="mb-3"><?php echo e(ucfirst($product->name)); ?></h4>
                            <p class="mb-4">Rs. <?php echo e($product->price); ?></p>
                            <a class="btn addToCart" data-id="<?php echo e($product->id); ?>"><i
                                    class="fa fa-plus text-primary me-3"></i>Add to Cart</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>No Products found.</li>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Service End -->
    <div class="modal" id="addToCartModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cart added</h5>
                </div>
                <div class="modal-body">
                    <p>Product has been added.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="closeAddToCartModal">Ok</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                // Add to cart
                $(".addToCart").on('click', function() {
                    var productId = $(this).data('id');
                    $.ajax({
                        url: '/cart/add',
                        type: 'POST',
                        data: {
                            product: productId,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(data) {
                            $("#cartCounter").text(data.cartCount);
                            // Show the modal
                            $("#addToCartModal").show();
                        }
                    });
                });
                // Close the modal
                $("#closeAddToCartModal").on('click', function() {
                    $("#addToCartModal").hide();
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/store.blade.php ENDPATH**/ ?>