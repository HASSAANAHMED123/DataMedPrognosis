<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Admin | <?php echo $__env->yieldContent('title'); ?> </title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.min.css')); ?>">
    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"
        integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!--  Summernote css -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pretty-checkbox.min.css')); ?>">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
</head>

<body>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <?php if(auth()->guard()->check()): ?>
                
                <?php echo $__env->make('layouts.admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <?php echo $__env->make('layouts.admin.partials.side-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <main>
                    <div class="main-content">
                        <section class="section">
                            <div class="section-body">
                                <?php if (isset($component)) { $__componentOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.session-messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('session-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4)): ?>
<?php $attributes = $__attributesOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4; ?>
<?php unset($__attributesOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4)): ?>
<?php $component = $__componentOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4; ?>
<?php unset($__componentOriginal4b618dfe3ab6b4ad65822dcc90cd3bb4); ?>
<?php endif; ?>
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </section>
                    </div>
                </main>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <main>
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            <?php endif; ?>

        </div>
    </div>
    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- Template JS File -->
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <!-- Custom JS File -->
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>