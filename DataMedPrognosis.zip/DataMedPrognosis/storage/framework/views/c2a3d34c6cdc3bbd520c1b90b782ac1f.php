<div class="col-6">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('warn')): ?>
        <div class="alert alert-warning" role="alert">
            <?php echo e(session('warn')); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/components/session-messages.blade.php ENDPATH**/ ?>