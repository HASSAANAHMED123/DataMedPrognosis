<?php $__env->startSection('title', 'Book Appointment'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('customer.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Book Appointment')); ?></div>
                    <div class="card-body">
                        <!-- Appointment Start -->
                        <div class="container-xxl py-5">
                            <div class="container">
                                <div class="row g-5">
                                    <div class="col-lg-12 wow fadeInUp col-sm-12" data-wow-delay="0.5s">
                                        <div class="bg-light rounded h-100 d-flex align-items-center p-5">
                                            <form id="bookAppointmentForm">
                                                <div class="row g-3">
                                                    <div class="col-12 col-sm-12">
                                                        <div class="date" id="date" data-target-input="nearest">
                                                            <input type="date"
                                                                class="form-control border-0 datetimepicker-input"
                                                                placeholder="Choose Date"style="height: 55px;"
                                                                id="appointmentDate" min="<?php echo e(date('Y-m-d')); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <select class="form-select border-0" id="appointmentDoctor"
                                                            style="height: 55px;">
                                                            <option selected value="null">Choose
                                                                Doctor</option>
                                                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($doctor->id); ?>">
                                                                    <?php echo e($doctor->name); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="time" id="time" data-target-input="nearest">
                                                            <select class="form-select border-0" name="timeSlot"
                                                                id="availableSlots" style="height: 55px;">
                                                                <option selected>Choose Date and Doctor First</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <textarea class="form-control border-0" rows="5" id="description" placeholder="Describe your problem"></textarea>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="text-danger mb-3" id="error-message"></div>
                                                        <button class="btn btn-primary w-100 py-3" id="book-appointment-btn"
                                                            type="submit">Book
                                                            Appointment</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <div id="successfullMessageContainer" class="d-none">
                                                <div class="col-12">
                                                    <div class="alert alert-success" role="alert">
                                                        <h4 class="alert-heading">Appointment Booked Successfully!</h4>
                                                        <hr>
                                                        <p class="mb-0">
                                                            <a href="<?php echo e(route('my-appointments')); ?>"
                                                                class="btn btn-primary">Go to My
                                                                Appointments</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Appointment End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#appointmentDate').change(function(e) {
                    e.preventDefault();
                    getAndSetAvailableSlots()
                });

                $('#appointmentDoctor').change(function(e) {
                    e.preventDefault();
                    getAndSetAvailableSlots()
                });

                const getAndSetAvailableSlots = function() {
                    const date = $('#appointmentDate').val()
                    const doctorId = $('#appointmentDoctor').val()
                    if (doctorId == 'null') {
                        var select = $('#availableSlots');
                        select.empty(); // Clear existing options
                        return select.append($('<option></option>')
                            .attr('value', null)
                            .text('Choose Doctor and Date First.'));
                    }
                    $.ajax({
                        url: "<?php echo e(route('book-appointment.available-slots')); ?>",
                        type: 'Get',
                        data: {
                            date: date,
                            doctor: doctorId
                        },
                        success: function(response) {
                            // Handle the response from the server
                            const availableSlots = response.availableSlots;
                            var select = $('#availableSlots');
                            select.empty(); // Clear existing options
                            $.each(availableSlots, function(index, value) {
                                select.append($('<option></option>')
                                    .attr('value', value)
                                    .text(value));
                            });
                        },
                        error: function(xhr, status, error) {
                            // Handle errors
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $('#book-appointment-btn').click(function(e) {
                e.preventDefault();
                var doctor = $('#appointmentDoctor').val();
                var date = $('#appointmentDate').val();
                var timeSlot = $('#availableSlots').val();
                var description = $('#description').val();

                // Simple validation
                if (!doctor || doctor == null || !date || !timeSlot || !description) {
                    $('#error-message').text("Please fill in all fields.");
                    return;
                }
                if ($('#description').val().length < 20) {
                    $('#error-message').text("Description must be at least 20 characters.");
                    return;
                }
                // Reset error message
                $('#error-message').text("");
                // Form data
                var formData = {
                    doctor: doctor,
                    date: date,
                    timeSlot: timeSlot,
                    description: description
                };
                formData._token = "<?php echo e(csrf_token()); ?>";
                // AJAX request
                $.ajax({
                    url: "<?php echo e(route('book-appointment.book')); ?>",
                    type: "POST",
                    data: formData,
                    success: function(response) {
                        // Handle success response
                        $("#bookAppointmentForm").addClass('d-none');
                        $("#successfullMessageContainer").removeClass('d-none');

                    },
                    error: function(xhr) {
                        // Handle error
                        $('#error-message').text(xhr.responseText);
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/customer/book-appointment.blade.php ENDPATH**/ ?>