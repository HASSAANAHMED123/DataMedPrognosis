<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Main Content -->
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <?php echo $__env->make('admin.settings.partials.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card">
                <?php echo $__env->make('admin.settings.partials.change-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>