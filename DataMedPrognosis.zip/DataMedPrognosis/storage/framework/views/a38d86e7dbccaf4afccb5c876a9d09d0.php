<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Main Content -->
    <div class="container">
        <div class="row">
            <?php echo $__env->make('customer.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <div class="card p-3">
                                        <h5><?php echo e(ucfirst($key)); ?></h5>
                                        <div class="ml-auto">
                                            <h5><span class="text-success"> <?php echo e($value); ?></span></h5>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>