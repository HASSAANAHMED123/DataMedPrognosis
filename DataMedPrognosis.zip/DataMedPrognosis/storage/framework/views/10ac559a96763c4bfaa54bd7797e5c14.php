<div class="col-12 mt-5">
    <hr>
    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0 wow fadeIn" data-wow-delay="0.1s">
        <button type="button" class="navbar-toggler me-4 mb-2" data-bs-toggle="collapse"
            data-bs-target="#customerNavbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="customerNavbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="<?php echo e(route('customer-dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'nav-item nav-link',
                    'active' => request()->routeIs('customer-dashboard'),
                ]); ?>">Dashboard</a>
                <a href="<?php echo e(route('my-appointments')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'nav-item nav-link',
                    'active' => request()->routeIs('my-appointments'),
                ]); ?>">My Appointments</a>
                <a href="<?php echo e(route('my-orders')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'nav-item nav-link',
                    'active' => request()->routeIs('my-orders'),
                ]); ?>">My Orders</a>
                <a href="<?php echo e(route('book-appointment.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'nav-item nav-link',
                    'active' => request()->routeIs('book-appointment.index'),
                ]); ?>">Book Appointment</a>

                <a href="<?php echo e(route('profile.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'nav-item nav-link',
                    'active' => request()->routeIs('profile.index'),
                ]); ?>">Profile</a>
                <a class="nav-item nav-link text-danger" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                    <span> Logout</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH D:\Projects\DataMedPrognosis\resources\views/customer/partials/navbar.blade.php ENDPATH**/ ?>