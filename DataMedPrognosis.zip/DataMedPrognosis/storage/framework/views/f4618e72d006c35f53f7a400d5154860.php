<?php $__env->startSection('title', 'Disease predictor'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Disease predictor (AI)</h1>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Disease predictor Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Disease predictor</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-12 wow fadeIn" data-wow-delay="0.1s">
                    <div class="bg-light rounded p-5">
                        <?php
                            $symptoms = [
                                'fatigue',
                                'high_fever',
                                'headache',
                                'nausea',
                                'vomiting',
                                'abdominal_pain',
                                'cough',
                                'joint_pain',
                                'muscle_pain',
                                'dizziness',
                                'skin_rash',
                                'itching',
                                'belly_pain',
                            ];
                        ?>
                        <div id="questions">
                            <form id="predict-form">
                                <div class="row g-3">
                                    <?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12 ">
                                            <p> Q<?php echo e(++$key); ?>: Do you have
                                                <?php echo e(ucfirst(str_replace('_', ' ', $symptom))); ?>?</p>
                                            <input type="radio" name="<?php echo e($symptom); ?>" value="1"
                                                class="form-check-input">
                                            <label for="<?php echo e($symptom); ?>" class="form-check-label">Yes</label>

                                            <input type="radio" name="<?php echo e($symptom); ?>" value="0"
                                                class="form-check-input">
                                            <label class="form-check-label" for="<?php echo e($symptom); ?>">No</label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <hr>
                                    <div class="col-12">
                                        <button id="predict-btn" class="btn btn-primary w-25 py-3"
                                            type="button">Predict</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div id="prediction" style="display: none;">
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">Prediction</h4>
                                <p id="prediction-text"></p>
                            </div>
                        </div>
                        <div id="failure-prediction" style="display: none;">
                            <div class="alert alert-warning" role="alert">
                                <h4 class="alert-heading">Fail to Predict</h4>
                                <p> Due to technical reasons, model is unable to predict.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Disease predictor End -->
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#predict-btn').click(function() {
                    var symptoms = [];
                    $('input[type="radio"]:checked').each(function() {
                        symptoms.push($(this).val());
                    });

                    var symptomsStr = symptoms.join(',');
                    var url = '<?php echo e(route('disease-predictor.predict')); ?>?symptoms=' + symptomsStr;

                    $.get(url)
                        .done(function(data) {
                            // Handle success response
                            $('#questions').hide();
                            $('#prediction-text').text(
                                "According to the predictor model, you most probably have: " + data
                                .prediction
                            );
                            $('#prediction').show();
                        })
                        .fail(function(jqXHR, textStatus, errorThrown) {
                            // Handle error response
                            $('#questions').hide();
                            $('#failure-prediction').show();
                        });
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/disease-predictor.blade.php ENDPATH**/ ?>