<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Cart</h1>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Cart Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded-pill py-1 px-4">Cart</p>
            </div>
            <?php if(session()->has('orderPlaced')): ?>
                <div class="row g-4">
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Order Placed Successfully!</h4>
                        <hr>
                        <p class="mb-0">
                            <a href="<?php echo e(route('my-orders')); ?>" class="btn btn-primary">Go to My
                                Orders</a>
                        </p>
                    </div>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php if(filled($cart) && $cart->total_amount > 0): ?>
                        <div class="col-lg-12 wow fadeIn" data-wow-delay="0.1s">
                            <div class="bg-light rounded p-5">
                                <form>
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Product Name</th>
                                                        <th>Price (Rs)</th>
                                                        <th>Quantity</th>
                                                        <th>Total (Rs)</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $cart->load('items.product');
                                                    ?>
                                                    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($cartItem->product->name); ?></td>
                                                            <td><?php echo e($cartItem->product->price); ?></td>
                                                            <td><?php echo e($cartItem->quantity); ?></td>
                                                            <td><?php echo e($cartItem->product->price * $cartItem->quantity); ?>

                                                            </td>
                                                            <td>
                                                                <a href="<?php echo e(route('cart.remove', $cartItem->id)); ?>"
                                                                    class="link link-danger">Remove</a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan="2" class="text-end">
                                                            <h5> <strong>Total:</strong></h5>
                                                        </td>
                                                        <td colspan="3">
                                                            <h5> Rs <?php echo e($cart->total_amount); ?></h5>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-12 ">
                                            <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-primary w-25  py-3"
                                                type="submit">Checkout (Cash on
                                                Delivery)</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <li>Cart is empty.</li>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Cart End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Naveed Traders\Downloads\DataMedPrognosis\resources\views/cart.blade.php ENDPATH**/ ?>