import pickle
import os
import warnings
from typing import List
from fastapi import FastAPI, Query, HTTPException

app = FastAPI()

def load_model():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(script_dir, 'disease-predictor.pkl')
    with open(model_path, 'rb') as model_file:
        model = pickle.load(model_file)
    return model

def validate_symptoms(symptoms: List[int]):
    if len(symptoms) != 13:
        raise HTTPException(status_code=400, detail="Symptoms must contain 13 values")

@app.get("/predict")
def predict_symptoms(symptoms: str = Query(..., title="Symptoms")):
    symptoms_list = [int(x) for x in symptoms.split(',')]
    validate_symptoms(symptoms_list)
    model = load_model()

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        prediction = model.predict([symptoms_list])
    return prediction[0]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8080,
        reload=False,
    )
