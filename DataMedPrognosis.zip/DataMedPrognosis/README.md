## Project Setup Commands

1: composer install
2: npm install
3: npm run build
4: cp .env.example .env
5: php artisan key:generate
6: php artisan migrate:fresh --seed

## To run project

php artisan serve

## Admin Account

    admin@example.com
    password

## How to run predictor model script

Go to python folder in ai-model folder and run the script
