<?php

namespace App\Providers;

use App\Models\Cart;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Model::preventLazyLoading(env('APP_DEBUG', false));
        Paginator::useBootstrapFive();

        Gate::define('isAdmin', function (User $user) {
            return $user->isAdmin();
        });

        Gate::define('isCustomer', function (User $user) {
            return $user->isCustomer();
        });

        if (Schema::hasTable('carts')) {
            view()->composer('layouts.app.app', function ($view) {
                $cartCount = Cart::where('customer_id', auth()->id())->count();
                $view->with('cartCount', $cartCount);
            });
        }
    }
}
