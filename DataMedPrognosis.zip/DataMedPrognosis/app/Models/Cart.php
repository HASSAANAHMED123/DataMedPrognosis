<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Cart extends Model
{

    protected $fillable = ['customer_id'];

    public function customer()
    {
        return  $this->belongsTo(User::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(CartItem::class);
    }

    public function getTotalAmountAttribute()
    {
        $total = 0;
        $items = $this->items->load('product');
        foreach ($items as $item) {
            $total += $item->quantity * $item->product->price;
        }
        return $total;
    }

    public function getItemsCountAttribute()
    {
        return $this->items()->count();
    }
}
