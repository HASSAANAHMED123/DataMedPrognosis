<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
  use HasFactory;

  protected $fillable = [
    'doctor_id',
    'customer_id',
    'status',
    'desc',
    'date',
    'start_time',
    'finish_time',
  ];

  public function scopePendings($query)
  {
    return $query->where('status', 'pending');
  }

  public function doctor()
  {
    return  $this->belongsTo(Doctor::class);
  }

  public function customer()
  {
    return $this->belongsTo(User::class);
  }
}
