<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $cart = auth()->user()->cart;
        return view('cart', compact('cart'));
    }

    public function add(Request $request)
    {
        $cart = Cart::firstOrNew(['customer_id' => auth()->id()]);
        $cart->save();
        $cartItem = $cart->items()->where('product_id', $request->product)->first();
        if (filled($cartItem)) {
            $cartItem->increment('quantity');
        } else {
            $cart->items()->create([
                'product_id' => $request->product,
                'quantity' => 1,
            ]);
        }
        $cartItemsCount = $cart->items_count;
        return response()->json(['cartCount' => $cartItemsCount]);
    }

    public function remove(Request $request, CartItem $cartItem)
    {
        $cartItem->delete();
        return back();
    }

    public function checkout(Request $request)
    {
        /**
         * @var User $user
         */
        $user = auth()->user();
        $cart = $user->cart;
        if (filled($cart) && $cart->items()->count() > 0) {
            $order = $user->orders()->create();
            $order->save();
            $cart->items->load('product');
            $cart->items->each(function ($item) use (&$order) {
                $order->details()->create([
                    'product_id' => $item->product->id,
                    'unit_name' => $item->product->name,
                    'unit_price' => $item->product->price,
                    'quantity' => $item->quantity
                ]);
            });
            $cart->delete();
            return to_route('cart')->with('orderPlaced', true);
        }
        return to_route('cart');
    }
}
