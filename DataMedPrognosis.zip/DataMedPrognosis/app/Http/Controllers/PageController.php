<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Cart;
use App\Models\Doctor;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    public function welcome()
    {
        $doctors = Doctor::all();
        return view('welcome', compact('doctors'));
    }

    public function blogs()
    {
        $blogs = Blog::latest()->get();
        return view('blogs', compact('blogs'));
    }

    public function blogShow($blog)
    {
        $blog = Blog::where('slug', $blog)->first();
        abort_if(blank($blog), 404);
        return view('blog-show', compact('blog'));
    }

    public function contact()
    {
        return view('contact-us');
    }

    public function store()
    {
        $products = Product::where('name', 'LIKe', '%' . request()->query('search', '') . '%')
            ->get();
        return view('store', compact('products'));
    }
}
