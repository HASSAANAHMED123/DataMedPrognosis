<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;

class DiseasePredictorController extends Controller
{
    public function index()
    {
        return view('disease-predictor');
    }

    public function predict(Request $request)
    {
        $symptoms = $request->query('symptoms', [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]);
        $url = 'http://localhost:8080/predict?symptoms=' . $symptoms;
        try {
            //code...
            $response = Http::get($url);

            // Check if the API call was successful
            if ($response->getStatusCode() == 200) {
                $prediction = $response->getBody()->getContents();
                return response()->json(['prediction' => $prediction]);
            } else {
                return response()->json(['error' => 'Failed to predict disease.'], 500);
            }
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['error' => 'Failed to predict disease.'], 500);
        }
    }
}
