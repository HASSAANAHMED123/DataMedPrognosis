<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\Request;

class MyAppointmentController extends Controller
{
    public function index(Request $request)
    {
        $appointments = Appointment::where('customer_id', auth()->id())->with(['doctor', 'customer'])->latest()->paginate();
        return view('customer.my-appointments', compact('appointments'));
    }
}
