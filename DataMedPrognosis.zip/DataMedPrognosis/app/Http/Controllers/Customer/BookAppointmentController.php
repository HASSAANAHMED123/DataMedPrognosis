<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BookAppointmentController extends Controller
{
    public function index()
    {
        $doctors = Doctor::latest()->get();
        if (blank($doctors)) {
            return back()->with('error', 'No Doctors Available.');
        }
        return view('customer.book-appointment', compact('doctors'));
    }

    public function book(Request $request)
    {
        $availableSlots = $this->getAvailableSlots($request, false);
        // Validation rules
        $rules = [
            'doctor' => 'required|string|exists:doctors,id',
            'date' => 'required|date|after_or_equal:today',
            'timeSlot' => 'required|in:' . implode(',', $availableSlots),
            'description' => 'required|string|min:15',
        ];

        // Custom validation messages
        $errorMessages = [
            'doctor.exists' => 'The selected doctor does not exist.',
            'date.after_or_equal' => 'The date must be today or in the future.',
            'description.min' => 'Description must be at least 15 characters.',
        ];

        $validator = Validator::make($request->all(), $rules, $errorMessages);

        if ($validator->fails()) {
            return response()->json($validator->errors()->first(), 422);
        }

        $timeSlot = Carbon::parse($request->timeSlot);
        $start_time = $timeSlot->format('H:i');
        $finish_time = $timeSlot->addMinutes(30)->format('H:i');
        $requestDate = Carbon::createFromFormat('Y-m-d', $request->date)->format('d-m-Y');
        Appointment::create([
            'customer_id' => auth()->id(),
            'doctor_id' => $request->doctor,
            'date' => $requestDate,
            'start_time' => $start_time,
            'finish_time' => $finish_time,
            'desc' => $request->description,
        ]);

        return response()->json([
            'success' => true,
            'msg' => 'Appointment booked successfully.'
        ]);
    }

    private function getAppointmentTimeSlots()
    {
        $settings  = Setting::all();
        $hospitalOpeningTime = $settings->where('key', 'hospital_opening_time')->first()->value ?? '9:00';
        $hospitalClosingTime = $settings->where('key', 'hospital_closing_time')->first()->value ?? '17:00';
        $appointmentDuration = intval($settings->where('key', 'appointment_duration')->first()->value ?? '30');

        $start = Carbon::parse($hospitalOpeningTime);
        $end = Carbon::parse($hospitalClosingTime);

        $timeSlots = [];

        while ($start < $end) {
            $timeSlots[] = $start->format('H:i');
            $start->addMinutes($appointmentDuration);
        }

        return $timeSlots;
    }

    public function getAvailableSlots(Request $request, $json = true)
    {
        $timeSlots = $this->getAppointmentTimeSlots();
        $requestDate = Carbon::createFromFormat('Y-m-d', $request->date)->format('d-m-Y');
        $bookedAppointments = Appointment::where('date', $requestDate)
            ->where('doctor_id', $request->doctor)
            ->get();

        $bookedSlots  = [];

        foreach ($bookedAppointments as $bookedAppointment) {
            $bookedSlots[] = $bookedAppointment->start_time;
        }

        $availableSlots = array_diff($timeSlots, $bookedSlots);

        if ($json) {
            // If it's an AJAX request or a JSON request, return JSON
            return response()->json(['availableSlots' => $availableSlots]);
        }

        return $availableSlots;
    }
}
