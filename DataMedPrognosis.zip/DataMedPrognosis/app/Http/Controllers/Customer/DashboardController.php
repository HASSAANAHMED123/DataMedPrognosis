<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $today = now()->format('Y-m-d');
        $todayAppointmentsCount = Appointment::where('customer_id', auth()->id())
            ->whereDate('created_at', $today)->count();

        $totalAppointmentsCount = Appointment::where('customer_id', auth()->id())
            ->whereDate('created_at', $today)->count();

        $cards = [
            'Appointments Today' => $todayAppointmentsCount,
            'Total Appointments' => $totalAppointmentsCount,
        ];
        return view('customer.dashboard', compact('cards'));
    }
}
