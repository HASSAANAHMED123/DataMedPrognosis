<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function index()
    {
        $doctors = Doctor::withCount('appointments')
            ->where('name', 'LIKE', '%' . request()->query('search', '') . '%')
            ->latest()->paginate();
        return view('admin.doctors.index', compact('doctors'));
    }

    public function createOrUpdate(Request $request, $id = null)
    {
        $isUpdate =  $id ? true : false;
        $doctor = $isUpdate ? Doctor::findOrFail($id) : new Doctor();
        // Validation
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:doctors,email,' . $id,
            'department' => 'required|string|max:255',
        ];
        if (!$isUpdate) {
            $rules['image'] = 'required|image|mimes:jpeg,png,jpg,gif|max:5000';
        }
        $request->validate($rules);
        // Creating or updating 
        $doctor->name = $request->input('name');
        $doctor->email = $request->input('email');
        $doctor->department = $request->input('department');
        $doctor->save();
        if ($request->hasFile('image')) {
            // Replace the existing media with the new image
            $doctor->addMedia($request->file('image'))
                ->toMediaCollection('display-photo');
        }
        if ($isUpdate) {
            return to_route('doctors.index')
                ->with('success', 'Doctor updated successfully.');
        }
        return to_route('doctors.index')
            ->with('success', 'Doctor created successfully.');
    }

    public function create()
    {
        return view('admin.doctors.create-or-update');
    }

    public function edit($id)
    {
        $doctor = Doctor::findOrFail($id);
        return view('admin.doctors.create-or-update', compact('doctor'));
    }

    public function store(Request $request)
    {
        return $this->createOrUpdate($request);
    }

    public function update(Request $request, $id)
    {
        return $this->createOrUpdate($request, $id);
    }

    public function destroy($id)
    {
        $doctor = Doctor::findOrFail($id);
        if ($doctor->appointments()->count() > 0) {
            return back()->with('error', 'Doctor is associated with appointments. Unable to delete.');
        }
        $doctor->delete();
        return redirect()->route('doctors.index')->with('success', 'Doctor deleted successfully.');
    }
}
