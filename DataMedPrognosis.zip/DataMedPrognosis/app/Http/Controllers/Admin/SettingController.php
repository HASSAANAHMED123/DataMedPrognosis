<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class SettingController extends Controller
{
    public function index()
    {
        $settings = Setting::all();
        return view('admin.settings.index', compact('settings'));
    }

    public function store(Request $request)
    {
        
        $validatedData = $request->validate([
            'hospital_opening_time' => 'required|date_format:H:i',
            'hospital_closing_time' => 'required|date_format:H:i|after:hospital_opening_time',
            // 'appointment_duration' => 'required|numeric|in:15,30,60,120',
        ]);

        foreach ($validatedData as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }

        return redirect()->back()->with('success', 'Settings updated successfully.');
    }
}
