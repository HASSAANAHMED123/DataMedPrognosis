<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function index()
    {
        $appointments = Appointment::with(['doctor', 'customer'])
            ->whereHas('customer', function ($query) {
                $query->where('name', 'LIKE', '%' . request()->query('search', '') . '%');
            })
            ->orWhereHas('doctor', function ($query) {
                $query->where('name', 'LIKE', '%' . request()->query('search', '') . '%');
            })
            ->latest()
            ->paginate();

        return view('admin.appointments.index', compact('appointments'));
    }

    public function accepted(Request $request, Appointment $appointment)
    {
        if ($appointment->status != 'pending') {
            return back()->with('error', '');
        }
        $appointment->status = 'accepted';
        $appointment->save();
        return back()->with('success', 'Appointment has been accepted successfully.');
    }

    public function rejected(Request $request, Appointment $appointment)
    {
        if ($appointment->status != 'pending') {
            return back()->with('error', '');
        }
        $appointment->status = 'rejected';
        $appointment->save();
        return back()->with('success', 'Appointment has been rejected successfully.');
    }
}
