<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blog::with('media')
            ->where('title', 'LIKE', '%' . request()->query('search', '') . '%')
            ->latest()->paginate(10);
        return view('admin.blogs.index', compact('blogs'));
    }

    public function create()
    {
        return view('admin.blogs.create-or-update');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|max:1000|unique:blogs,title',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:5000',
            'short_desc' => 'required|string|min:10|max:500',
            'blog' => 'required|string|min:30|max:9999999999'
        ]);

        $blog = Blog::create([
            'title' => $request->title,
            'short_desc' => $request->short_desc,
            'blog' => $request->blog,
        ]);

        if ($request->hasFile('image')) {
            $blog->addMedia($request->file('image'))
                ->toMediaCollection('cover-photo');
        }
        return redirect()->route('blogs.index')
            ->with('success', 'Blog created successfully.');

        return redirect()->route('blogs.index')->with('success', 'Blog entry created successfully.');
    }

    public function edit(Blog $blog)
    {
        return view('admin.blogs.create-or-update', compact('blog'));
    }

    public function update(Request $request, Blog $blog)
    {
        $request->validate([
            'title' => 'required|max:1000|unique:blogs,title,' . $blog->id,
            'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'short_desc' => 'required|string|min:10|max:500',
            'blog' => 'required|string|min:30|max:4294967295'
        ]);

        $blog->update([
            'title' => $request->title,
            'short_desc' => $request->short_desc,
            'blog' => $request->blog,
        ]);

        if ($request->hasFile('image')) {
            // Replace the existing media with the new image
            $blog->addMedia($request->file('image'))
                ->toMediaCollection('cover-photo');
        }

        return redirect()->route('blogs.index')
            ->with('success', 'Blog updated successfully.');
    }

    public function destroy(Blog $blog)
    {
        $blog->delete();

        return redirect()->route(
            'blogs.index'
        )->with('success', 'Blog deleted successfully.');
    }
}
