<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Order;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $today = now()->format('Y-m-d');
        $appointmentsCount = Appointment::whereDate('created_at', $today)->count();
        $ordersCount = Order::whereDate('created_at', $today)->count();
        $customersCount = User::customers()->count();

        $cards = [
            'Appointments Today ' => $appointmentsCount,
            'Orders Today ' => $ordersCount,
            'Total Customers ' => $customersCount,
        ];
        return view('admin.dashboard', compact('cards'));
    }
}
