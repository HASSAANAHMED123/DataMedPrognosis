<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = User::customers()
            ->withCount('appointments')
            ->where('name', 'LIKE', '%' . request()->query('search', '') . '%')
            ->latest('id')
            ->paginate();
        return view('admin.customers.index', compact('customers'));
    }
}
