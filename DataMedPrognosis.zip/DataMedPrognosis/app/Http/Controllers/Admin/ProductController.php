<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::latest()->paginate();
        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        return view('admin.products.create-or-update');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'price' => 'required|numeric',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:5000',
        ]);

        $product = Product::create([
            'name' => $request->name,
            'price' => $request->price,
        ]);

        if ($request->hasFile('image')) {
            $product->addMedia($request->file('image'))
                ->toMediaCollection('thumbnail');
        }

        return to_route('products.index')->with('success', 'Product created successfully.');
    }

    public function edit(Product $product)
    {
        return view('admin.products.create-or-update', compact('product'));
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required|string',
            'price' => 'required|numeric',
        ]);

        $product->update([
            'name' => $request->name,
            'price' => $request->price,
        ]);

        if ($request->hasFile('image')) {
            $product->addMedia($request->file('image'))
                ->toMediaCollection('thumbnail');
        }
        return to_route('products.index')->with('success', 'Product updated successfully.');
    }

    public function destroy(Product $product)
    {
        if ($product->cart()->count() > 0) {
            return back()->with('error', 'Product is associated with order. Unable to delete.');
        }
        $product->delete();
        return back()->with('success', 'Product deleted successfully.');
    }
}
